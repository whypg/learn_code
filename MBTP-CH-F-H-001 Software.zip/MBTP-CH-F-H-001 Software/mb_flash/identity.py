#!/usr/bin/env python3
# Copyright (c) 2019, Maidbot, Inc.
# All rights reserved.

import time
import re

import logging
log_format = '[%(levelname)s] %(asctime)s: %(message)s'
logging.basicConfig(format=log_format)
log = logging.getLogger(__name__)
log.setLevel(logging.INFO)


class Field(object):

    def __init__(self, value, position, type_=int, num_bytes=1, offset=0,
                 validation_str=None, min_=None, max_=None):
        try:
            self._value = type_(value)
        except ValueError:
            self._value = ''
        self.position = position
        self.type = type_
        self.num_bytes = num_bytes
        self.offset = offset  # num bits offset from initial byte
        self.validation_str = validation_str
        self.min = min_
        self.max = max_

    def update(self, value):
        try:
            self._value = self.type(value)
        except ValueError:
            self._value = ''

    def get(self):
        try:
            return self.type(self._value)
        except ValueError:
            return ''

    def as_hex(self):
        if self.type == str:
            hex_bytes = [ord(c).to_bytes(1, byteorder='big').hex().upper() for c in self._value]
            hex_bytes += ['0'] * max((self.num_bytes - len(hex_bytes), 0))
            return ''.join(hex_bytes)
        return self._value.to_bytes(self.num_bytes, byteorder='big').hex().upper()

    def from_hex(self, hex_value):
        if self.type == str:
            self._value = bytes.fromhex(hex_value).decode('ascii').replace('\x00','')
            return
        self._value = self.type(hex_value, 16)

    def validate(self):
        v = self.get()
        if type(v) is not self.type:
            log.debug("{} was type {}, not type {}".format(v, type(v), self.type))
            return False

        if self.min is not None and v < self.min:
            log.debug("{} was smaller than {}".format(v, self.min))
            return False

        if self.max is not None and v > self.max:
            log.debug("{} was larger than {}".format(v, self.max))
            return False

        if self.validation_str is not None:
            if not re.match(self.validation_str, v, flags=re.I):
                log.debug("{} did not match {}".format(v, self.validation_str))
                return False

        return True

class Identity(object):

    def __init__(self,
                 eeprom_rev='',
                 hardware_rev='',
                 timestamp='',
                 building='',
                 floor='',
                 line='',
                 lot='',
                 maidbot_device_type='',
                 maidbot_device_id=''):
        self.eeprom_rev = Field(eeprom_rev, 0, min_=1, max_=255)
        self.hardware_rev = Field(hardware_rev, 1, min_=1, max_=255)
        self.timestamp = Field(timestamp, 2, num_bytes=4, min_=1546304400, max_=1640998800)
        self.building = Field(building, 6, min_=1, max_=15)
        self.floor = Field(floor, 6, offset=4, min_=1, max_=15)
        self.line = Field(line, 7, min_=1, max_=255)
        self.lot = Field(lot, 8, num_bytes=4, min_=0, max_=(2**(8*4)-1))
        self.maidbot_device_type = Field(maidbot_device_type, 12, num_bytes=2, min_=1, max_=(2**(8*2)-1))
        self.maidbot_device_id = Field(maidbot_device_id, 14, type_=str, num_bytes=12,
                                       validation_str=r"^[0-9A-V]{12}$")

    def update(self, key, value):
        self.__dict__[key].update(value)

    def to_dict(self):
        return {k: v for k, v in self.__dict__.items() if k[0] != '_'}

    def to_bytes(self):
        d = self.to_dict()
        bldg_and_floor = d.pop('building').get() + (d.pop('floor').get() << 4)
        d['bldg_and_floor'] = Field(bldg_and_floor, 6)
        return sorted([(f.position, f.as_hex()) for f in d.values()], key=lambda tup: tup[0]) 

    @classmethod
    def from_bytes(cls, byte_string):
        identity = Identity()

        for key, field in identity.to_dict().items():
            hex_value = byte_string[field.position*2:(2*(field.position + field.num_bytes))]
            if key == 'building':
                hex_value = '0' + hex_value[1]
            if key == 'floor':
                hex_value = '0' + hex_value[0]

            field.from_hex(hex_value)

        return identity

    def to_csv(self, include_header_row=False):
        """Generate a comma-separated ID record.

        Represented as a single list without header row, or a list of
        lists with header row.
        """ 
        # Explicit to maintain order
        csv = [
            str(self.timestamp.get()),
            str(self.maidbot_device_type.get()),
            str(self.maidbot_device_id.get()),
            str(self.eeprom_rev.get()),
            str(self.hardware_rev.get()),
            str(self.building.get()),
            str(self.floor.get()),
            str(self.line.get()),
            str(self.lot.get()),
        ] 
        if not include_header_row:
            return csv
        header = [
            'timestamp',
            'maidbot_device_type',
            'maidbot_device_id',
            'eeprom_rev',
            'hardware_rev',
            'building',
            'floor',
            'line',
            'lot',
        ]
        return [header, csv]



    def to_nvs_csv(self):
        """Generate the esp32 input csv for flashing NVS.

        See https://docs.espressif.com/projects/esp-idf/en/latest/api-reference/storage/nvs_partition_gen.html
        """
        csv = []
        csv.append(['key','type','encoding','value'])
        csv.append(['nvs','namespace',',',','])
        csv.append(['eeprom_rev','data','u8',str(self.eeprom_rev.get())])
        csv.append(['hardware_rev','data','u8',str(self.hardware_rev.get())])
        csv.append(['timestamp','data','u32',str(self.timestamp.get())])
        csv.append(['building','data','u8',str(self.building.get())])
        csv.append(['floor','data','u8',str(self.floor.get())])
        csv.append(['line','data','u8',str(self.line.get())])
        csv.append(['lot','data','u32',str(self.lot.get())])
        csv.append(['device_type','data','u16',str(self.maidbot_device_type.get())])
        csv.append(['device_id','data','string',str(self.maidbot_device_id.get())])
        return "\n".join([",".join(row) for row in csv])

    def __str__(self):
        return 'Identity: \n\t- ' + "\n\t- ".join(['{}: {}'.format(k, f.get()) for k, f in self.__dict__.items()])

    def validate(self):
        return all([f.validate() for f in self.to_dict().values()])


FAKE_ID = {
    'eeprom_rev': 1,
    'hardware_rev': 2,
    'timestamp': time.time(),
    'building': 12,
    'floor': 3,
    'line': 4,
    'lot': 5,
    'maidbot_device_type': 6,
    'maidbot_device_id': '43sa54d12era',
}
FAKE_ID = Identity(**FAKE_ID)

BATTERY_ID = {
    'eeprom_rev': 3,
    'hardware_rev': 3,
    'timestamp': time.time(),
    'building': 1,
    'floor': 1,
    'line': 1,
    'lot': '',
    'maidbot_device_type': 4,
    'maidbot_device_id': '',
}
BATTERY_ID = Identity(**BATTERY_ID)

CHARGER_ID = {
    'eeprom_rev': 3,
    'hardware_rev': 3,
    'timestamp': time.time(),
    'building': 1,
    'floor': 1,
    'line': 1,
    'lot': 0,
    'maidbot_device_type': 7,
    'maidbot_device_id': '',
}
CHARGER_ID = Identity(**CHARGER_ID)

MOTOR_ID = {
    'eeprom_rev': 3,
    'hardware_rev': 4,
    'timestamp': time.time(),
    'building': 1,
    'floor': 1,
    'line': 1,
    'lot': '',
    'maidbot_device_type': 1,
    'maidbot_device_id': '',
}
MOTOR_ID = Identity(**MOTOR_ID)

FSB_ID = {
    'eeprom_rev': 3,
    'hardware_rev': 4,
    'timestamp': time.time(),
    'building': 1,
    'floor': 1,
    'line': 1,
    'lot': '',
    'maidbot_device_type': 3,
    'maidbot_device_id': '',
}
FSB_ID = Identity(**FSB_ID)

if __name__ == "__main__":
    # print(FAKE_ID)
    # print(FAKE_ID.to_bytes())
    print(FAKE_ID.to_csv())
    print(FAKE_ID.to_csv(True))
