#!/usr/bin/env python3
# Copyright (c) 2019, Maidbot, Inc.
# All rights reserved.

""" 
Upload functions to interface with avrdude.
"""

import os
import sys
import subprocess

from pathlib import Path
import pprint
import tempfile

from mb_flash.identity import CHARGER_ID, Identity
from mb_flash.targets import ESP_TARGETS as TARGETS
import serial.tools.list_ports

import logging
log_format = '[%(levelname)s] %(asctime)s: %(message)s'
logging.basicConfig(format=log_format)
log = logging.getLogger(__name__)
log.setLevel(logging.DEBUG)

__authors__ = ('Nick Sweet')


def run(cmd, timeout=30):
    """Run a shell command, returning STDOUT and STDERR if not timed out."""
    log.debug(' '.join(cmd))
    try:
        proc = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=timeout)
    except subprocess.TimeoutExpired as e:
        log.error("Command timed out after {}s!\n{}".format(timeout, e))
        sys.exit(1)
    
    out = proc.stdout.decode("utf-8")
    log.debug(out)
    return out


class EspConfig(object):
    def __init__(self, name, port=None, baud=921600):
        if name not in TARGETS.keys():
            log.error("{} was not a valid target! Use {}"
                      .format(name, TARGETS.keys()))
            sys.exit(1)
        self.name = name
        self.baud = baud
        self.nvs = {}
        self.driver = {}
        self.port = port

        # Set up paths
        # NOTE: We assume this file exists one directory above the root
        project_root = Path(__file__).resolve().parents[1]
        esp_root = project_root / 'tools' / 'esp'
        self.binaries_path = project_root / 'bin'
        self.partition_gen = esp_root / 'nvs_partition_gen.py'
        self.partition_table_gen = esp_root / 'gen_esp32part.py'
        self.esptool = esp_root / 'esptool.py'

        self._load_target()  # Must happen before select_port
        self._selct_port(port)

        self.flash = self.driver['flash']
        log.debug(self)

    def _selct_port(self, port=None):
        # Use user-specified port
        if port is not None:
            self.port = port
            return

        # Use port loaded from target
        if self.port is not None:
            return

        # Use scanned port
        ports = list(serial.tools.list_ports.comports())
        for p in ports:
            if 'usb serial' in str(p).lower():
                self.port = p.device
                return

        # Use system-default port
        if sys.platform == 'win32':
            self.port = 'COM3'
        else:
            self.port = '/dev/ttyUSB0'

    def __str__(self):
        return 'EspConfig: ' + pprint.pformat(self.__dict__)

    def _load_target(self):
        try:
            target = TARGETS[self.name]
        except KeyError as e:
            log.error('Target {} is not specified in TARGETS.'
                    .format(self.name))
            raise e

        # Add all target info to self for dot notation access
        for k, v in target.items():
            try:
              v['flash'] = self.binaries_path / v['flash']
            except (KeyError, TypeError):
                pass
            setattr(self, k, v)

        return target


PARTITION_TABLE = [
    ['nvs',      'data', 'nvs',     '0x9000',  '0x4000',],
    ['otadata',  'data', 'ota',     '0xd000',  '0x2000',],
    ['phy_init', 'data', 'phy',     '0xf000',  '0x1000',],
    ['factory',  '0',    '0',       '0x10000', '1M',],
    ['ota_0',    '0',    'ota_0',   '',        '1M',],
    ['ota_1',    '0',    'ota_1',   '',        '1M',],
]



def flash_eeprom(target='charger', identity=None, timeout=10, 
                 save_record=True, **kwargs):
    """Flash the device's eeprom."""
    config = EspConfig(target, **kwargs)

    if identity is None:
        log.error("No identity information provided.")
        sys.exit(1)
    data = identity.to_nvs_csv()
    filename = _generate_nvs(target, data)

    cmd = ['python', str(config.esptool),
           '--port', config.port,
           '--after', 'no_reset',
           'write_flash', config.nvs['offset'],
           filename]

    log.info('Uploading NVS to flash...')
    out = run(cmd)
    success = True
    # TODO - should we read eeprom back over serial?

    if 'Failed to connect to Espressif device' in out:
        log.error(out)
        log.error('Did you:')
        log.error('\t- connect the programming pins JProg?')
        log.error('\t- power cycle the board?')
        log.error('\t- close all other serial terminals?')
        success = False
    elif 'Hash of data verified.' not in out:
        log.error(out)
        success = False
    else:
        log.info("Successfully flashed NVS to {}!".format(target))

    if save_record:
        _record_outcome(target, success, identity)

    return success, out

def read_eeprom(target, **kwargs):
    """Read the device's eeprom"""
    config = EspConfig(target, **kwargs)

    filename = str(Path(tempfile.gettempdir()) / 'esp_nvs_part.bin')

    cmd = ['python', str(config.esptool),
           '--port', config.port,
           '--after', 'no_reset',
           'read_flash', config.nvs['offset'],
           filename]

    run(cmd)

    with open(filename) as f:
        eeprom = f.read()

    success = len(eeprom) > 0

    return success, eeprom

def read_identity(target, **kwargs):
    """Flash the device's eeprom"""

    success, eeprom = read_eeprom(target, **kwargs)
    if not success:
        return success, eeprom
    parsed_bytes = _parse_nvs_partition(eeprom)
    identity = Identity.from_bytes(parsed_bytes)
    log.debug(identity)
    
    return success, identity

def flash_driver(target, timeout=60, **kwargs):
    """ Upload driver firmware to the ESP chip """
    config = EspConfig(target, **kwargs)

    cmd = ['python', str(config.esptool),
           '--port', config.port,
           '--baud', str(config.baud),
           '--after', 'no_reset',
           'write_flash', config.driver['offset'],
           str(config.driver['flash'])]

    log.info('Uploading driver to flash...')
    out = run(cmd)
    
    if 'Failed to connect to Espressif device' in out:
        log.error(out)
        log.error('Did you:')
        log.error('\t- connect the programming pins JProg?')
        log.error('\t- power cycle the board?')
        log.error('\t- close all other serial terminals?')
        return False, ''
    
    if 'Hash of data verified.' not in out:
        log.error(out)
        return False, ''

    # TODO - should we read eeprom back over serial?
    log.info("Successfully flashed driver to {}!".format(target))
    return True, ''

def flash_partition_table(target='charger', timeout=60, **kwargs):
    """ Upload driver firmware to the ESP chip """
    config = EspConfig(target, **kwargs)

    filename = _generate_partition_table_bin(target)
    cmd = ['python', str(config.esptool),
           '--port', config.port,
           '--baud', str(config.baud),
           '--after', 'no_reset',
           'write_flash', '0x8000',
           filename]

    log.info('Uploading partition table...')
    out = run(cmd)
    
    if ('No such file or directory' in out
        or 'Failed to connect to Espressif device' in out):
        log.error(out)
        log.error('Did you:')
        log.error('\t- connect the programming pins JProg?')
        log.error('\t- power cycle the board?')
        log.error('\t- close all other serial terminals?')
        return False, ''

    if 'Hash of data verified.' not in out:
        log.error(out)
        return False, ''

    log.info("Successfully flashed partition table to {}!".format(target))
    return True, ''

def _record_outcome(target, success, identity, outfile=None):
    if outfile is None:
        project_root = Path(__file__).resolve().parents[1]
        outfile = project_root / 'data' / 'flash_record.csv'

    outfile.parents[0].mkdir(parents=True, exist_ok=True)
    include_header_row = not outfile.exists()

    data = identity.to_csv(include_header_row)
    with open(str(outfile), 'a+') as f:
        if include_header_row:
            data[0] = ['target', 'success'] + data[0]
            csv = ','.join(data[0]) + os.linesep
            f.write(csv)
            data = data[1]

        data = [target, str(success)] + data
        csv = ','.join(data) + os.linesep
        f.write(csv)

def _generate_nvs(target, data, **kwargs):
    """Generate a binary to be put in the non-volatile storage partition.
    
    `data` should be passed in as a CSV string
    """
    config = EspConfig(target, **kwargs)

    partition_csv_path = str(Path(tempfile.gettempdir()) / 'nvs_partition.csv')
    partition_bin_path = str(Path(tempfile.gettempdir()) / 'nvs_partition.bin')
    with open(partition_csv_path, 'w+') as f:
        f.write(data)

    cmd = ['python', str(config.partition_gen), 
           'generate', partition_csv_path,
           partition_bin_path, config.nvs['size']
    ]
    
    log.debug("Generating NVS from csv: \n{}".format(data))
    out = run(cmd)
    log.debug(out)

    return partition_bin_path

def _parse_nvs_partition(eeprom):
    """Read a blob of eeprom hex from a device.

    Output is the eeprom as one hex string, stripped of any 
    non-payload fields.
    """
    print(eeprom)
    eeprom_data = ''
    for d in eeprom.split('\n'):
        d = d[9:-2]
        eeprom_data += d

    return eeprom_data

def _generate_partition_table_bin(target, **kwargs):
    """Generate a binary to define the ESP's partitions."""
    config = EspConfig(target, **kwargs)

    table_csv_path = str(Path(tempfile.gettempdir()) / 'esp32_partition_table.csv')
    table_bin_path = str(Path(tempfile.gettempdir()) / 'esp32_partition_table.bin')
    table = '\n'.join([','.join(p) for p in PARTITION_TABLE])
    with open(table_csv_path, 'w+') as f:
        f.write(table)

    cmd = ['python', str(config.partition_table_gen), 
           table_csv_path, table_bin_path,
           '--disable-md5sum'
    ]
    
    log.debug("Generating partition table from csv: \n{}".format(table))
    out = run(cmd)

    return table_bin_path

if __name__ == "__main__":
    # print(EspConfig('charger'))
    # identity = CHARGER_ID
    # identity.update('lot', 1)
    # identity.update('maidbot_device_id', 'deadbeef')
    # flash_eeprom('charger', identity)
    # flash_driver('charger')
    _generate_partition_table_bin('charger')

    # list_usb_interfaces('battery')
    # print(read_eeprom('battery'))
    # flash_eeprom('battery', FAKE_ID)
