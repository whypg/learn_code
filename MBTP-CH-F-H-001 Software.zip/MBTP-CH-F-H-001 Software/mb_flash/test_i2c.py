#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Copyright (c) 2019 Maidbot, Inc. All rights reserved.
"""

from __future__ import print_function, division

import logging
import functools
import time
import tkinter as tk
import itertools
from tkinter.scrolledtext import ScrolledText
import threading
import queue
from threading import Lock
import serial
import serial.tools.list_ports

import sys
sys.path.insert(0, '.')

logging.basicConfig(format='[%(levelname)s] %(asctime)s: %(message)s')
log = logging.getLogger(__name__)
log.setLevel(logging.DEBUG)


__authors__ = ("nick@maidbot.com (Nick Sweet)")

DARK_MAIDBOT = '#08222e'
GREEN = '#17826e'
GREEN_ACTIVE = '#147160'


def rate_limit(rate_hz):
    """
    Function decorator that enforces a time interval between function calls.
    """
    def wrapper(func):
        if rate_hz < 1e-6:
            raise ValueError("Rate is way too small!")

        @functools.wraps(func)
        def wrapped_func(*args, **kwargs):
            now = time.time()
            period = 1 / rate_hz
            if now - wrapped_func.latest > period:
                func(*args, **kwargs)
                wrapped_func.latest = now
        wrapped_func.latest = time.time()
        return wrapped_func
    return wrapper


class DataEntry():

    def __init__(self, name, default_value, value=None, element=None):
        self.default_value = default_value
        self.name = name
        self.value = value
        self.element = element

    def as_cmd(self):
        v = self.value.get().lower()
        if 'read' in v:
            return 'r'
        
        if 'write' in v:
            return 'w'
        
        # Decode hex
        if 'x' in v:
            return str(int(v, 16))
        
        return v


class I2CTeensyGui:
    """Gui for i2c communication over a Teensy intermediary."""

    def __init__(self, title='i2c Tester'):
        self.title = title
        self.tk = tk.Tk()
        self.tk.title(self.title)
        self.tk.configure(bg=DARK_MAIDBOT)
        self.lock = Lock()            

        self.console = None
        self.device_entry = DataEntry('Device Address', '0x00')
        self.register_entry = DataEntry('Register Address', '0x00')
        self.rw_entry = DataEntry('Read/Write', 'Read')
        self.data_entry = DataEntry('Data', '')
        self.entries = [self.device_entry, self.rw_entry, self.register_entry, self.data_entry]
        self.current_focus = None
        
        row = 0
        row = self._create_title(row)
        row = self._create_cmd_entry(row)
        row = self._create_console(row)

        self.serial_tx_queue = queue.Queue()
        self.serial_rx_queue = queue.Queue()
        self.serial_state_queue = queue.Queue()
        self.serial_client = ThreadedSerialClient(self.serial_rx_queue, self.serial_tx_queue,
                                                  self.serial_state_queue)

        self.tk.bind("<Return>", self._send_cmd)
        self.tk.bind("<Tab>", self._shift_focus)
        self.gui_update_period_ms = 100 # ms
        self._gui_update()
        self.tk.mainloop()

    def log(self, msg):
        self.console.insert(tk.END, msg)
        self.console.yview(tk.END)

    def _gui_update(self):
        self._read_data()

        self.tk.update_idletasks()
        self.tk.update()
        self.tk.after(self.gui_update_period_ms, self._gui_update)


    def _create_title(self, row=0):
        title = tk.Label(self.tk, text=self.title, width="40", height="1",
                      background=DARK_MAIDBOT, fg='white', font=('Helvetica', 16))
        title.grid(column=0, columnspan=4, row=row)
        row += 1

        meta_text = "i2c using Sparkfun Teensy 3.1"
        meta = tk.Label(self.tk, text=meta_text, width="0", height="1",
                     background=DARK_MAIDBOT, fg='white', font=('Helvetica', 10))
        meta.grid(column=0, columnspan=6, row=row, pady=(0, 20))
        return row + 1

    def _create_cmd_entry(self, row=0):
        for i, entry in enumerate(self.entries):
            label = tk.Label(self.tk, text=entry.name, height="2",
                          background=DARK_MAIDBOT, bd=1, fg='white', justify=tk.CENTER)
            label.grid(row=row, column=i)

            entry.value = tk.StringVar(self.tk)
            entry.value.set(entry.default_value)

            if entry == self.rw_entry:
                continue
            entry.element = tk.Entry(self.tk, textvariable=entry.value, width="10",
                                  background='black', fg='white', insertbackground='white')
            entry.element.grid(row=(row+1), column=i)

        self.rw_entry.element = tk.OptionMenu(self.tk, self.rw_entry.value, "Read", "Write")
        self.rw_entry.element.grid(row=(row+1), column=1, columnspan=1)
        self._shift_focus()

        return row + 2

    def _create_console(self, row=0):
        self.console = ScrolledText(self.tk, height="20",
                            background='black', fg='white')
        self.console.grid(row=row, column=0, columnspan=4,
                          pady=10, ipadx=1, ipady=1)
        return row + 1

    def _make_cmd(self):
        return ' '.join([e.as_cmd() for e in self.entries]).strip()

    def _send_cmd(self, event):
        with self.lock:
            cmd = self._make_cmd()
            self.serial_tx_queue.put(cmd)
            self.log("[SENT] {}\n".format(cmd))
            log.debug([ord(c) for c in cmd])

    def _read_data(self):
        while self.serial_state_queue.qsize():
            connection_changed, is_connected = self.serial_state_queue.get(0)
            if not connection_changed:
                break

            status = "CONNECTED" if is_connected else "DISCONNECTED"
            
            with self.lock:
                self.log("[{}] Port: {}\n".format(status, self.serial_client.config['port']))

        data = ''
        while self.serial_rx_queue.qsize():
            try:
                data = self.serial_rx_queue.get(0)
            except queue.Empty:
                pass

        if not data:
            return

        self.log("[RECV] {}\n".format(data))            

    def _shift_focus(self, event=None):
        focus_elements = [e.element for e in self.entries if isinstance(e.element, tk.Entry)]
        if not focus_elements:
            return 'break'

        if self.current_focus is None:
            self.current_focus = focus_elements[0]
        else:
            i = focus_elements.index(self.current_focus)
            if i >= (len(focus_elements) - 1):
                self.current_focus = focus_elements[0]
            else:
                self.current_focus = focus_elements[i+1]
        self.current_focus.focus_set()
        return 'break'


    def destroy(self):
        try:
            self.tk.destroy()
        except tk.TclError:
            pass  # Already destroyed!


class I2COverSerial:
    """Handle Serial interface to I2C commanding device."""

    def __init__(self):
        ports = list(serial.tools.list_ports.comports())
        log.debug("Available Serial Ports: {}".format([p.device for p in ports]))
        port = '/dev/ttyACM0'
        for p in ports:
            if 'serial' in str(p).lower():
                port = p.device

        self.connections = [False]
        self.config = {
            'port': port,
            'baudrate': 115200,
            'timeout': 0.5,
            'write_timeout': 0.5
        }

    def get_connection_state(self):
        """Returns if changed and current state. None if unknown."""
        if not self.connections:
            return False, None
        
        if all(self.connections) or not any(self.connections):
            return False, all(self.connections)

        is_connected = self.connections[-1]
        self.connections = []

        return True, is_connected
        

    def send_data(self, data):
        with serial.Serial(**self.config) as ser:
            ser.reset_input_buffer()
            # data_bytes = str.encode(data + '\r\n')
            # data_bytes = str.encode(data[:-1])
            # s = "ABCD"
            data_bytes = bytearray()
            data_bytes.extend(map(ord, data))
            log.debug("Sending {}".format(data_bytes))
            #TODO: Check false connection
            num_bytes_written = ser.write(data_bytes)
            self.connections.append(True)
            log.debug("Sent {}".format(num_bytes_written))
            time.sleep(0.01)
            ser.reset_output_buffer()
        # self.read_data()

    def read_data(self):
        response = b''
        try:
            with serial.Serial(**self.config) as ser:
                # while ser.inWaiting() > 0:
                #     response += ser.read(1)
                # response = response.decode().replace('\r', '').replace('\n', '')

                # response = ser.readline().decode().replace('\r', '').replace('\n', '')

                response = ser.readlines()
                # print([(type(r), r, r.decode().replace('\r', '').replace('\n', '')) for r in response])
                rs = [r.decode().replace('\r', '').replace('\n', '') for r in response]
                response = "\n".join(rs)

                ser.reset_output_buffer()

                log.debug("Got: {}".format(response))
        except serial.serialutil.SerialException:
            self.connections.append(False)
            return

        self.connections.append(True)
        return response

class ThreadedSerialClient:
    """Owner of a serial client thread."""
    def __init__(self, serial_rx_queue, serial_tx_queue, serial_state_queue):
        self.serial_state_queue = serial_state_queue
        self.serial_rx_queue = serial_rx_queue
        self.serial_tx_queue = serial_tx_queue
        self.serial_client = I2COverSerial()
        self.config = self.serial_client.config
        self.thread = threading.Thread(target=self._update_serial_cx)
        self.thread.start()

    def _update_serial_cx(self):
        while True:
            tx_data = ''
            rx_data = ''
            while self.serial_tx_queue.qsize():
                try:
                    tx_data = self.serial_tx_queue.get(0)
                except queue.Empty:
                    pass
                self.serial_client.send_data(tx_data)

            rx_data = self.serial_client.read_data()
            if rx_data:
                self.serial_rx_queue.put(rx_data)
            
            state = self.serial_client.get_connection_state()
            self.serial_state_queue.put(state) 






if __name__ == "__main__":
    gui = I2CTeensyGui()

    # s = I2COverSerial()
    # while True:
    #     data = s.read_data()
    #     time.sleep(0.1)