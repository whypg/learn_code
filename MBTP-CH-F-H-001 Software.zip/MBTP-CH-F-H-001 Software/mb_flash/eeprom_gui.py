#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Copyright (c) 2019 Maidbot, Inc. All rights reserved.
"""

from __future__ import print_function, division

import logging
import functools
import time

import tkinter
from tkinter import TclError, Tk, Label, Button, StringVar, Entry, Text   # Python 3

import sys
sys.path.insert(0, '.')

from mb_flash.identity import BATTERY_ID, CHARGER_ID, FSB_ID, MOTOR_ID
from mb_flash import avr, esp

logging.basicConfig(format='[%(levelname)s] %(asctime)s: %(message)s')
log = logging.getLogger(__name__)
log.setLevel(logging.INFO)


__authors__ = ("nick@maidbot.com (Nick Sweet)")

DARK_MAIDBOT = '#08222e'
GREEN = '#17826e'
GREEN_ACTIVE = '#147160'


def rate_limit(rate_hz):
    """
    Function decorator that enforces a time interval between function calls.
    """
    def wrapper(func):
        if rate_hz < 1e-6:
            raise ValueError("Rate is way too small!")

        @functools.wraps(func)
        def wrapped_func(*args, **kwargs):
            now = time.time()
            period = 1 / rate_hz
            if now - wrapped_func.latest > period:
                func(*args, **kwargs)
                wrapped_func.latest = now
        wrapped_func.latest = time.time()
        return wrapped_func
    return wrapper


class BaseFlashingGui:
    """Common parts of our device Flashing GUI."""

    FIELDS = [
        'maidbot_device_id',
        'lot',
        'line',
        'floor',
        'building',
        'hardware_rev',
        'eeprom_rev',
        'maidbot_device_type',
        'timestamp',
    ]
    DISABLED_ENTRY = ['timestamp', 'maidbot_device_type',
                      'hardware_rev', 'eeprom_rev']

    def __init__(self, device_handler, target_name, title, test_name, test_id, part_id):
        self.device_handler = device_handler
        self.target_name = target_name
        self.tk = Tk()
        self.title = title
        self.test_name = test_name
        self.test_id = test_id
        self.part_id = part_id
        self.tk.title(self.title)
        self.tk.configure(bg=DARK_MAIDBOT)

        self.identity = None
        self.identity_entry = None
        self.maidbot_device_id = None
        self.console = None

        self.flash_button = None
        self.read_id_button = None

        self.tk.after(1000, self._update_timestamp)

    @rate_limit(rate_hz=20)
    def _update(self):
        self.tk.update_idletasks()
        self.tk.update()

    def _create_title(self, row=0):
        title = Label(self.tk, text=self.title, width="40", height="1",
                      background=DARK_MAIDBOT, fg='white', font=('Helvetica', 16))
        title.grid(column=0, columnspan=4, row=row)
        row += 1

        meta_text = "{} | {} | {}".format(
            self.test_name, self.test_id, self.part_id)
        meta = Label(self.tk, text=meta_text, width="0", height="1",
                     background=DARK_MAIDBOT, fg='white', font=('Helvetica', 10))
        meta.grid(column=0, columnspan=6, row=row, pady=(0, 20))
        return row + 1

    def _create_identity_entry(self, row=0):
        self.identity_entry = []

        fields = sorted(self.identity.to_dict().items(),
                        key=lambda pair: self.FIELDS.index(pair[0]))
        for key, field in fields:
            # Label
            label = Label(self.tk, text=key.title().replace('_', ' '), height="2",
                          background=DARK_MAIDBOT, bd=1, fg='white', justify=tkinter.LEFT)
            label.grid(row=row, column=1, sticky=tkinter.E)

            # Entry
            if key == 'maidbot_device_id':
                self.maidbot_device_id = StringVar()
                entry = Entry(self.tk, textvariable=self.maidbot_device_id)

                # Limit entry to 12 characters
                self.maidbot_device_id.trace('w',
                                             lambda name, index, mode, sv=self.maidbot_device_id:
                                             self.maidbot_device_id.set(self.maidbot_device_id.get()[:12]))
            else:
                entry = Entry(self.tk)
            entry.grid(row=row, column=2, padx=5)
            entry.insert(tkinter.END, field.get())
            if key in self.DISABLED_ENTRY:
                entry.configure(state='disabled')
            row += 1

            self.identity_entry.append((label, entry))
        return row

    def _create_buttons(self, row=0, read_identity=True):
        button_config = {
            'background': GREEN,
            'highlightbackground': GREEN_ACTIVE,
            'activebackground': GREEN_ACTIVE,
            'activeforeground': 'white',
            'width': "20",
            'height': "1"
        }
        self.flash_button = Button(self.tk, command=self.flash,
                                   text='Flash', font=('Helvetica', 14))
        self.flash_button.config(**button_config)
        self.flash_button.configure(state='disabled')

        if read_identity:
            self.read_id_button = Button(self.tk, command=self.read_identity,
                                         text='Read MID', font=('Helvetica', 14))
            self.read_id_button.config(**button_config)
            self.read_id_button.grid(row=row, column=0, columnspan=2, pady=10,)
            self.flash_button.grid(row=row, column=2, columnspan=2, pady=10,)
        else:
            self.flash_button.grid(row=row, column=1, columnspan=2, pady=10,)

        self.tk.bind("<KeyRelease>", self._key_release)

        return row + 1

    def _create_console(self, row=0):
        self.console = Text(self.tk, height="20",
                            background='black', fg='white')
        self.console.grid(row=row, column=0, columnspan=4,
                          pady=10, ipadx=1, ipady=1)
        return row + 1

    def _key_release(self, event):
        self._update_identity()
        self._check_flash()

    def _check_flash(self):
        flash_ready = self.identity.validate()
        state = 'active' if flash_ready else 'disabled'
        self.flash_button.configure(state=state)

    def _update_identity(self):
        for label, entry in self.identity_entry:
            field_name = label.cget('text').lower().replace(' ', '_')
            self.identity.update(field_name, entry.get())

    def _clear_device_id(self):
        for label, entry in self.identity_entry:
            field_name = label.cget('text').lower().replace(' ', '_')
            if field_name == 'maidbot_device_id':
                self.identity.update(field_name, '')
                entry.delete(0, tkinter.END)
        self._update_identity()
        self._check_flash()

    def _update_timestamp(self):
        for label, entry in self.identity_entry:
            field_name = label.cget('text').lower().replace(' ', '_')
            if field_name == 'timestamp':
                t = int(time.time())
                self.identity.update(field_name, t)
                entry.configure(state='normal')
                entry.delete(0, tkinter.END)
                entry.insert(tkinter.END, str(t))
                entry.configure(state='disabled')
        self.tk.after(1000, self._update_timestamp)

    def flash(self):
        """Reads identity back from EEPROM.

        TODO: should avr be default? This is overloaded by ESP devices
        """
        self.console.delete(1.0, tkinter.END)
        self.console.insert(tkinter.END, "Writing to EEPROM:\n")
        self.console.insert(tkinter.END, str(self.identity))
        self._update()
        w_success, w_out = self.device_handler.flash_eeprom(
            self.target_name, self.identity)
        r_success, r_out = self.device_handler.read_eeprom(self.target_name)
        compare_success = w_out == r_out

        if not w_success:
            self.console.insert(tkinter.END, "\nFailed to write EEPROM.\n")
        elif not r_success:
            self.console.insert(tkinter.END, "\nFailed to read EEPROM.\n")
        elif not r_success:
            self.console.insert(
                tkinter.END, "\nEEPROM written did not match EEPROM read.\n")
        elif compare_success:
            self.console.insert(
                tkinter.END, "\nEEPROM Successfully Written!\n")
        self._clear_device_id()
        self._update()

        if log.getEffectiveLevel() == logging.DEBUG:
            self.console.insert(tkinter.END, r_out)

    def read_identity(self):
        """Reads identity back from EEPROM.

        TODO: also read from ESP32 devices!
        """
        self.console.delete(1.0, tkinter.END)
        self.console.insert(tkinter.END, "Reading identity from EEPROM...\n")
        self._update()
        try:
            success, identity = self.device_handler.read_identity(
                self.target_name)
            if not success:
                fail_msg = identity
        except Exception as e:
            success = False
            fail_msg = str(e)

        if success:
            self.console.insert(tkinter.END, "\n{}\n".format(identity))
        else:
            self.console.insert(
                tkinter.END, "\nFailed to read EEPROM.\n{}".format(fail_msg))
        self._update()

    def destroy(self):
        try:
            self.tk.destroy()
        except TclError:
            pass  # Already destroyed!


class BatteryEepromGui(BaseFlashingGui):
    def __init__(self):
        super().__init__(device_handler=avr,
                         target_name='battery',
                         title='Battery EEPROM Configuration',
                         test_name='Battery Illumination Board MID Programming',
                         test_id='MBTP-BT-H-U-005',
                         part_id='RS-EP-16',
                         )

        self.identity = BATTERY_ID

        row = 0
        row = self._create_title(row)
        row = self._create_identity_entry(row)
        row = self._create_buttons(row)
        row = self._create_console(row)

        self.tk.mainloop()


class ChargerEepromGui(BaseFlashingGui):
    DISABLED_ENTRY = ['timestamp', 'maidbot_device_type',
                      'hardware_rev', 'eeprom_rev', 'lot']

    def __init__(self):
        super().__init__(device_handler=esp,
                         target_name='charger',
                         title='Charger EEPROM Configuration',
                         test_name='System Assembly Check Charger',
                         test_id='MBTP-CH-H-G-001',
                         part_id='RS-EP-45',
                         )

        self.identity = CHARGER_ID

        row = 0
        row = self._create_title(row)
        row = self._create_identity_entry(row)
        row = self._create_buttons(row)
        row = self._create_console(row)

        self.tk.mainloop()

    def flash(self):
        self.console.delete(1.0, tkinter.END)
        self.console.insert(tkinter.END, "Writing to EEPROM:\n")
        self.console.insert(tkinter.END, str(self.identity))
        self._update()
        w_success, = self.device_handler.flash_eeprom(
            self.target_name, self.identity)

        # w_success, w_out = self.device_handler.flash_eeprom(
        #     self.target_name, self.identity)
        # w_success, w_out = self.device_handler.flash_eeprom(self.target_name, self.identity)
        # r_success, r_out = self.device_handler.read_eeprom(self.target_name)  # TODO
        # compare_success = w_out == r_out

        if not w_success:
            self.console.insert(tkinter.END, "\nFailed to write EEPROM.\n")
        else:
            self.console.insert(
                tkinter.END, "\nEEPROM Successfully Written!\n")


class MotorEepromGui(BaseFlashingGui):
    def __init__(self):
        super().__init__(device_handler=avr,
                         target_name='motor',
                         title='Motor EEPROM Configuration',
                         test_name='Motor Check 2 - Wheel Motor',
                         test_id='MBTP-RS-H-D-002',
                         part_id='RS-EP-56',
                         )

        self.identity = MOTOR_ID

        row = 0
        row = self._create_title(row)
        row = self._create_identity_entry(row)
        row = self._create_buttons(row)
        row = self._create_console(row)

        self.tk.mainloop()


class FsbEepromGui(BaseFlashingGui):
    def __init__(self):
        super().__init__(device_handler=avr,
                         target_name='fsb',
                         title='FSB EEPROM Configuration',
                         test_name='Front Sensor Board Assembly',
                         test_id='MBTP-RS-S-H-001',
                         part_id='RS-EP-42',
                         )

        self.identity = FSB_ID

        row = 0
        row = self._create_title(row)
        row = self._create_identity_entry(row)
        row = self._create_buttons(row)
        row = self._create_console(row)

        self.tk.mainloop()


if __name__ == '__main__':
    # gui = BatteryEepromGui()
    # gui = ChargerEepromGui()
    # gui = MotorEepromGui()
    gui = FsbEepromGui()
