#!/usr/bin/env python3
# Copyright (c) 2019, Maidbot, Inc.
# All rights reserved.

"""
Target definitions.
"""

__authors__ = ('Nick Sweet')

AVR_TARGETS = \
    {
        'motor':
        {
            'flash': 'motor_v1-factory.hex',
            'board': 't84',
            'baudrate': '115200',
            'eeprom':
            {
                'size': 512,
                'line_byte_count': 32,
                'starting_address': 0,
            },
            'efuse': '0xFF',
            'hfuse': '0xD5',
            'lfuse': '0xE2',
        },

        'battery':
        {
            'flash': 'battery_v4.hex',
            'board': 't84',
            'baudrate': '115200',
            'eeprom':
            {
                'size': 512,
                'line_byte_count': 32,
                'starting_address': 0,
            },
            'efuse': '0xFF',
            'hfuse': '0xD5',
            'lfuse': '0xE2',
        },

        'fsb':
        {
            'flash': 'fsb_v4.hex',
            'board': 't828',
            'baudrate': '115200',
            'eeprom':
            {
                'size': 256,
                'line_byte_count': 32,  # TODO - validate!!!
                'starting_address': 0,
            },
            'efuse': '0xAF',
            'hfuse': '0xD5',
            'lfuse': '0x6E',
        }
    }

ESP_TARGETS = \
    {
        'charger':
        {
            # Specification should match partition.csv
            'driver':
            {
                'flash': 'charger_v1.0-factory.bin',
                'name': 'factory',
                'offset': '0x10000',
                'size': '1M',
            },
            'nvs':
            {
                # flash filename is generated at runtime
                'name': 'nvs',
                'offset': '0x9000',
                'size': '0x4000',
            },
            # 'port': 'COM6',  # use to override OS-based defaults
        }
    }
