#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Copyright (c) 2019 Maidbot, Inc. All rights reserved.
"""

from __future__ import print_function, division

import logging
import functools
import time

from pathlib import Path

from tkinter.filedialog import askopenfilename
import tkinter as tk
import sys
sys.path.insert(0, '.')

from mb_flash import avr, esp

logging.basicConfig(format='[%(levelname)s] %(asctime)s: %(message)s')
log = logging.getLogger(__name__)
log.setLevel(logging.INFO)


__authors__ = ("nick@maidbot.com (Nick Sweet)")

DARK_MAIDBOT = '#08222e'
GREEN = '#17826e'
GREEN_ACTIVE = '#147160'


def rate_limit(rate_hz):
    """
    Function decorator that enforces a time interval between function calls.
    """
    def wrapper(func):
        if rate_hz < 1e-6:
            raise ValueError("Rate is way too small!")

        @functools.wraps(func)
        def wrapped_func(*args, **kwargs):
            now = time.time()
            period = 1 / rate_hz
            if now - wrapped_func.latest > period:
                func(*args, **kwargs)
                wrapped_func.latest = now
        wrapped_func.latest = time.time()
        return wrapped_func
    return wrapper


class BaseDriverFlashingGui:
    """Common parts of our device Flashing GUI."""

    def __init__(self, device_handler, target_name, title, test_name, test_id, part_id):
        self.device_handler = device_handler
        self.target_name = target_name
        self.tk = tk.Tk()
        self.title = title
        self.test_name = test_name
        self.test_id = test_id
        self.part_id = part_id
        self.tk.title(self.title)
        self.tk.configure(bg=DARK_MAIDBOT)

        if device_handler is esp:
            self.binary_file = esp.EspConfig(self.target_name).flash
        else:
            self.binary_file = avr.AVRDudeConfig(self.target_name).flash

        self.binary_path_display = None
        self.console = None

        self.flash_button = None
        self.load_button = None
        self.pre_flash_button = None

        self.tk.after(1000, self._update)

    @rate_limit(rate_hz=20)
    def _update(self):
        self._check_flash()
        self.tk.update_idletasks()
        self.tk.update()

    def _create_title(self, row=0):
        title = tk.Label(self.tk, text=self.title, width="40", height="1",
                         background=DARK_MAIDBOT, fg='white', font=('Helvetica', 16))
        title.grid(column=0, columnspan=4, row=row)
        row += 1

        meta_text = "{} | {} | {}".format(
            self.test_name, self.test_id, self.part_id)
        meta = tk.Label(self.tk, text=meta_text, width="0", height="1",
                     background=DARK_MAIDBOT, fg='white', font=('Helvetica', 10))
        meta.grid(column=0, columnspan=6, row=row, pady=(0, 20))
        return row + 1

    def _create_path_display(self, row=0):
        button_config = {
            'background': GREEN,
            'highlightbackground': GREEN_ACTIVE,
            'activebackground': GREEN_ACTIVE,
            'activeforeground': 'white',
            'width': "10",
            'height': "1"
        }
        self.load_button = tk.Button(self.tk, command=self._load_binary_file,
                                   text='Load', font=('Helvetica', 14))
        self.load_button.config(**button_config)
        self.load_button.grid(row=row, column=0, columnspan=1, padx=(40, 0), pady=10, sticky=tk.W)

        self.binary_path_display = tk.StringVar()
        self._set_path_display()
        path_label = tk.Label(self.tk, textvar=self.binary_path_display, width="40", height="1",
                         background='white', fg='black', font=('Helvetica', 12), anchor='w')
        path_label.grid(column=1, columnspan=3, row=row, padx=20, sticky=tk.E)

        return row + 1

    def _set_path_display(self):
        path = str(self .binary_file.resolve())
        if len(path) > 50: # To quote Gwen: hackhackhalck
            path = '...' + path[-47:]
        self.binary_path_display.set(path)

    def _create_buttons(self, row=0):
        button_config = {
            'background': GREEN,
            'highlightbackground': GREEN_ACTIVE,
            'activebackground': GREEN_ACTIVE,
            'activeforeground': 'white',
            'width': "20",
            'height': "1"
        }

        if self.device_handler is avr:
            button = tk.Button(self.tk, command=self.burn_fuses,
                                   text='Burn Fuses', font=('Helvetica', 14))
            button.configure(state='disabled')  #TODO: get this working, then enable
        else:
            button = tk.Button(self.tk, command=self.set_partitions,
                                   text='Set Partitions', font=('Helvetica', 14))
            
        button.config(**button_config)
        button.grid(row=row, column=0, columnspan=2, pady=10,)
        self.pre_flash_button = button

        self.flash_button = tk.Button(self.tk, command=self.flash,
                                   text='Flash', font=('Helvetica', 14))
        self.flash_button.config(**button_config)
        self.flash_button.configure(state='disabled')
        self.flash_button.grid(row=row, column=2, columnspan=2, pady=10,)

        self._check_flash()
        self.tk.bind("<KeyRelease>", self._key_release)

        return row + 1

    def _create_console(self, row=0):
        self.console = tk.Text(self.tk, height="20",
                            background='black', fg='white')
        self.console.grid(row=row, column=0, columnspan=4,
                          pady=10, ipadx=1, ipady=1)
        if self.device_handler is esp:
            port = esp.EspConfig(self.target_name).port
            self.console.insert(tk.END, "Configured to use port {}.\n".format(port))
        return row + 1

    def _key_release(self, event):
        self._check_flash()

    def _load_binary_file(self):
        filetypes = (("Binary files", "*.bin *.hex"),
                     ("All files", "*.*"))
        intialdir = str(self.binary_file.resolve().parents[0])
        fname = askopenfilename(title="Load binary to flash",
                                filetypes=filetypes,
                                initialdir=intialdir)

        log.debug("Loaded file {}".format(fname))
        if fname:
            self.binary_file = Path(fname)
            self._set_path_display()

        self._update()

    def _check_flash(self):
        state = 'disabled'
        if self.binary_file.exists():
            self._set_path_display()
            state = 'active'
        self.flash_button.configure(state=state)

    def burn_fuses(self):
        """Write device driver file to device.

        TODO: should avr be default? This is overloaded by ESP devices
        """
        config = avr.AVRDudeConfig(self.target_name)
        fuses = '  E Fuse: {}\n  H Fuse: {}\n  L Fuse: {}'.format(config.efuse, config.hfuse, config.lfuse)
        self.console.delete(1.0, tk.END)
        self.console.insert(tk.END, "Burning fuses for {}:\n{}".format(self.target_name, fuses))
        self._update()
        success, out = self.device_handler.burn_fuses(self.target_name)

        if log.getEffectiveLevel() == logging.DEBUG:
            self.console.insert(tk.END, out)

        if success:
            self.console.insert(tk.END, "\nSuccessfully burnt fuses.\n")
        else:
            self.console.insert(tk.END, "\nFailed to burn fuses.\n")
        self._update()

    def set_partitions(self):
        table = '\n'.join(['\t\t'.join(p) for p in esp.PARTITION_TABLE])
        self.console.delete(1.0, tk.END)
        self.console.insert(tk.END, "Setting partition table for {}:\n\n{}\n\n".format(self.target_name, table))
        self._update()
        success, out = esp.flash_partition_table(self.target_name)

        if log.getEffectiveLevel() == logging.DEBUG:
            self.console.insert(tk.END, out)

        if success:
            self.console.insert(tk.END, "\nSuccessfully flashed partition table.\n")
        else:
            self.console.insert(tk.END, "\nFailed to flash partition table.\n")
        self._update()


    def flash(self):
        """Write device driver file to device.

        TODO: should avr be default? This is overloaded by ESP devices
        """
        self.console.delete(1.0, tk.END)
        self.console.insert(tk.END, "Flashing Driver to {}:\n".format(self.target_name))
        self.console.insert(tk.END, str(self.binary_file))
        self._update()
        success, out = self.device_handler.flash_driver(self.target_name)

        if log.getEffectiveLevel() == logging.DEBUG:
            self.console.insert(tk.END, out)

        if success:
            self.console.insert(tk.END, "\nDriver successfully flashed!\n")
        else:
            self.console.insert(tk.END, "\nFailed to flash driver.\n")
        self._update()

    def destroy(self):
        try:
            self.tk.destroy()
        except tk.TclError:
            pass  # Already destroyed!


class BatteryDriverGui(BaseDriverFlashingGui):
    def __init__(self):
        super().__init__(device_handler=avr,
                         target_name='battery',
                         title='Flash Battery Driver',
                         test_name='Battery Illumination Board FCT - RS-EP-16',
                         test_id='MBTP-BT-F-B-001',
                         part_id='RS-EP-16',
                         )
        row = 0
        row = self._create_title(row)
        row = self._create_path_display(row)
        row = self._create_buttons(row)
        row = self._create_console(row)

        self.tk.mainloop()


class ChargerDriverGui(BaseDriverFlashingGui):

    def __init__(self):
        super().__init__(device_handler=esp,
                         target_name='charger',
                         title='Flash Charger Driver',
                         test_name='Battery Charger Control Board',
                         test_id='MBTP-CH-F-H-001',
                         part_id='RS-EP-45',
                         )

        row = 0
        row = self._create_title(row)
        row = self._create_path_display(row)
        row = self._create_buttons(row)
        row = self._create_console(row)

        self.tk.mainloop()


class MotorDriverGui(BaseDriverFlashingGui):
    def __init__(self):
        super().__init__(device_handler=avr,
                         target_name='motor',
                         title='Motor EEPROM Configuration',
                         test_name='Motor Check 2 - Wheel Motor',
                         test_id='MBTP-RS-H-D-002',
                         part_id='RS-EP-56',
                         )
        row = 0
        row = self._create_title(row)
        row = self._create_path_display(row)
        row = self._create_buttons(row)
        row = self._create_console(row)

        self.tk.mainloop()


class FsbDriverGui(BaseDriverFlashingGui):
    def __init__(self):
        super().__init__(device_handler=avr,
                         target_name='fsb',
                         title='FSB EEPROM Configuration',
                         test_name='Front Sensor Board Assembly',
                         test_id='MBTP-RS-S-H-001',
                         part_id='RS-EP-42',
                         )

        row = 0
        row = self._create_title(row)
        row = self._create_path_display(row)
        row = self._create_buttons(row)
        row = self._create_console(row)

        self.tk.mainloop()


if __name__ == '__main__':
    # gui = BatteryDriverGui()
    gui = ChargerDriverGui()
    # gui = MotorDriverGui()
    # gui = FsbDriverGui()
