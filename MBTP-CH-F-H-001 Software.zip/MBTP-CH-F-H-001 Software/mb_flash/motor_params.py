#!/usr/bin/env python3
# Copyright (c) 2019, Maidbot, Inc.
# All rights reserved.

import time
import pprint
from pathlib import Path

import re

import logging
log_format = '[%(levelname)s] %(asctime)s: %(message)s'
logging.basicConfig(format=log_format)
log = logging.getLogger(__name__)
log.setLevel(logging.INFO)


class Field(object):

    def __init__(self, value, position, type_=int, num_bytes=1, offset=0,
                 validation_str=None, min_=None, max_=None):
        try:
            self._value = type_(value)
        except ValueError:
            self._value = ''
        self.position = position
        self.type = type_
        self.num_bytes = num_bytes
        self.offset = offset  # num bits offset from initial byte
        self.validation_str = validation_str
        self.min = min_
        self.max = max_

    def update(self, value):
        try:
            self._value = self.type(value)
        except ValueError:
            self._value = ''

    def get(self):
        try:
            return self.type(self._value)
        except ValueError:
            return ''

    def as_hex(self):
        if self.type == str:
            return decode_string(self._value, 32)
        return self._value.to_bytes(self.num_bytes, byteorder='big').hex().upper()

    def validate(self):
        v = self.get()
        if type(v) is not self.type:
            logging.debug("{} was type {}, not type {}".format(v, type(v), self.type))
            return False

        if self.min is not None and v < self.min:
            logging.debug("{} was smaller than {}".format(v, self.min))
            return False

        if self.max is not None and v > self.max:
            logging.debug("{} was larger than {}".format(v, self.max))
            return False

        if self.validation_str is not None:
            if not re.match(self.validation_str, v, flags=re.I):
                logging.debug("{} did not match {}".format(v, self.validation_str))
                return False

        return True

class MotorParams(object):
    EEPROM_OFFSET = 128

    def __init__(self,
                 motor_param_block_rev='',
                 motor_type='',
                 max_amp_x_100='',
                 no_load_rpm='',
                 ratio_x_10='',
                 pulses_per_rev='',
                 direction='',
                 maidbot_device_type='',
                 maidbot_device_id=''):
        self.motor_param_block_rev = Field(motor_param_block_rev, 0, min_=1, max_=255)
        self.motor_type = Field(motor_type, 1, num_bytes=2, min_=1, max_=(2**(8*2)-1))
        self.max_amp_x_100 = Field(max_amp_x_100, 3, min_=1, max_=255)
        self.no_load_rpm = Field(no_load_rpm, 4, num_bytes=2, min_=1, max_=(2**(8*2)-1))
        self.ratio_x_10 = Field(ratio_x_10, 6, num_bytes=2, min_=1, max_=(2**(8*2)-1))
        self.pulses_per_rev = Field(pulses_per_rev, 8, min_=1, max_=255)
        self.direction = Field(direction, 9, type_=bool)

    def update(self, key, value):
        self.__dict__[key].update(value)

    def to_dict(self):
        return {k: v for k, v in self.__dict__.items() if k[0] != '_'}

    def to_bytes(self):
        off = MotorParams.EEPROM_OFFSET
        return sorted([(f.position + off, f.as_hex()) for f in self.to_dict().values()], key=lambda tup: tup[0]) 

    def __str__(self):
        return 'Motor Params: \n\t- ' + "\n\t- ".join(['{}: {}'.format(k, f.get()) for k, f in self.__dict__.items()])

    def validate(self):
        return all([f.validate() for f in self.to_dict().values()])

def encode_integer(integer, base,
                   numerals="0123456789abcdefghijklmnopqrstuvwxyz"):
    """Encode an integer using an arbitrary base.

    See https://stackoverflow.com/a/2267428/362703 as a reference.
    """
    if base > len(numerals):
        logging.warn("Cannot encode {}: Base is larger than numeral set!"
                     .format(integer))
        return None

    integer = int(integer)
    if (integer == 0):
        return numerals[0]

    s = encode_integer(integer // base, base, numerals)
    return s.lstrip(numerals[0]) + numerals[integer % base]


def decode_string(encoded_string, base,
                   numerals="0123456789abcdefghijklmnopqrstuv"):
    """Encode an integer using an arbitrary base.

    See https://stackoverflow.com/a/2267428/362703 as a reference.
    """
    s = ''
    for char in encoded_string:
        s += "{0:0{1}X}".format(numerals.index(char.lower()), 2)
    return s


MOTOR_PARAMS = {
    'motor_param_block_rev': 3,
    'motor_type': 2432,
    'max_amp_x_100': 100,
    'no_load_rpm': 6600,
    'ratio_x_10': 450,
    'pulses_per_rev': 3,
    'direction': 1,
}
MOTOR_PARAMS = MotorParams(**MOTOR_PARAMS)

if __name__ == "__main__":
    print(MOTOR_PARAMS)
    print(MOTOR_PARAMS.to_bytes())
    # print(decode_string('43sa54d12h2', 32))
    # print(decode_string('11A', 32))

