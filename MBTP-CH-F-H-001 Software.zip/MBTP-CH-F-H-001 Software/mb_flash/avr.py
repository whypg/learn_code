#!/usr/bin/env python3
# Copyright (c) 2019, Maidbot, Inc.
# All rights reserved.

""" 
Upload functions to interface with avrdude.
"""

import os
import sys
import subprocess
import re

from pathlib import Path
import pprint
import tempfile

from mb_flash.targets import AVR_TARGETS as TARGETS
from mb_flash.motor_params import MOTOR_PARAMS
from mb_flash.identity import Identity

import logging
log_format = '[%(levelname)s] %(asctime)s: %(message)s'
logging.basicConfig(format=log_format)
log = logging.getLogger(__name__)
log.setLevel(logging.DEBUG)

__authors__ = ('Nick Sweet')



def run(cmd, timeout=30):
    """Run a shell command, returning STDOUT and STDERR if not timed out."""
    log.debug(' '.join(cmd))
    try:
        proc = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=timeout)
    except subprocess.TimeoutExpired as e:
        log.error("Command timed out after {}s!\n{}".format(timeout, e))
        sys.exit(1)
    
    out = proc.stdout.decode("utf-8")
    log.debug(out)
    return out


class AVRDudeConfig(object):
    def __init__(self, name, uploader="avrispmkII", port='usb'):
        if name not in TARGETS.keys():
            log.error("{} was not a valid target! Use {}"
                      .format(name, TARGETS.keys()))
            sys.exit(1)
        self.name = name 
        self.uploader = uploader
        self.port = port  # TODO
        self.flash = None

        # Set up paths
        # NOTE: We assume this file exists one directory above the root
        project_root = Path(__file__).resolve().parents[1]
        avrdude_root = project_root / 'tools' / 'avrdude'
        self.binaries_path = project_root / 'bin'
        self.avrdude_bin = avrdude_root / 'avrdude'
        self.avrdude_config = avrdude_root / 'avrdude.conf'

        self._load_target()
        log.debug(str(self))

    def __str__(self):
        return 'AVRDudeConfig: ' + pprint.pformat(self.__dict__)

    def _load_target(self):

        try:
            target = TARGETS[self.name]
        except KeyError as e:
            log.error('Target {} is not specified in TARGETS.'
                    .format(self.name))
            raise e

        # Add all target info to self for dot notation access
        for k, v in target.items():
            if k in ['flash']:
                v = self.binaries_path / v
            setattr(self, k, v)

        return target

def flash_eeprom(target, identity=None, save_record=True, **kwargs):
    """Flash the device's eeprom"""
    config = AVRDudeConfig(target, **kwargs)

    if identity is None:
        log.error("No identity information provided.")
        sys.exit(1)
    data = identity.to_bytes()
    if target in ['motor']:
        data += MOTOR_PARAMS.to_bytes()
    config.eeprom['filename'] = _generate_eeprom(target, data)

    # See https://www.nongnu.org/avrdude/user-manual/avrdude_4.html
    cmd = [str(config.avrdude_bin),
          '-p', config.board,
          '-b', config.baudrate,
          '-C', str(config.avrdude_config),
          '-c', config.uploader,
          '-P', config.port,
          '-D', # Disable auto-erase flash
          '-U', 'eeprom:w:{}:i'.format(config.eeprom['filename'])]

    log.info('Uploading to flash...')
    out = run(cmd)
    success = 'bytes of eeprom verified' in out

    with open(config.eeprom['filename'], 'r+') as f:
        eeprom_out = f.read()

    if save_record:
        _record_outcome(target, success, identity)
    return success, eeprom_out

def read_eeprom(target, **kwargs):
    """Flash the device's eeprom"""
    config = AVRDudeConfig(target, **kwargs)
    # TODO .\avrdude.exe -v -p attiny84 -c usbtiny -D -U eeprom:r:eeprom0.hex:i

    # See https://www.nongnu.org/avrdude/user-manual/avrdude_4.html
    
    cmd = [str(config.avrdude_bin),
          '-p', config.board,
          '-b', config.baudrate,
          '-C', str(config.avrdude_config),
          '-c', config.uploader,
          '-P', config.port,
          '-D', # Disable auto-erase flash
          '-U', 'eeprom:r:-:i']

    log.info('Reading eeprom...')
    out = run(cmd)

    eeprom_out = re.findall("\\n(:.*)", out)
    eeprom_out = '\n'.join(eeprom_out)
    success = len(eeprom_out) > 10
    return success, eeprom_out

def read_identity(target, **kwargs):
    """Read the device's  Maidbot Identity"""

    success, eeprom = read_eeprom(target, **kwargs)
    if not success:
        return success, eeprom
    parsed_eeprom = _parse_eeprom(eeprom)
    identity = Identity.from_bytes(parsed_eeprom)
    log.debug(identity)
    
    return success, identity

def flash_driver(target, **kwargs):
    """ Upload driver firmware to the AVR chip """
    config = AVRDudeConfig(target, **kwargs)

    # See https://www.nongnu.org/avrdude/user-manual/avrdude_4.html
    cmd = [str(config.avrdude_bin),
          '-p', config.board,
          '-b', config.baudrate,
          '-C', str(config.avrdude_config),
          '-c', config.uploader,
          '-P', config.port, '-v',
          '-Uflash:w:{}:i'.format(config.flash)]

    log.info('Uploading to flash...')
    out = run(cmd)
    success = 'bytes of flash verified' in out
    return success, out

def list_usb_interfaces(target_name, **kwargs):
    """List available USB devices for programming."""
    config = AVRDudeConfig(target_name, **kwargs)

    cmd = [str(config.avrdude_bin),
          '-p', config.board,
          '-b', config.baudrate,
          '-C', str(config.avrdude_config),
          '-c', config.uploader,
          '-P', 'usb:NODEVICE',
          '-v']
    out = run(cmd)
    return out


def burn_fuses(target, **kwargs):
    """Burn fuses on the AVR chip"""
    config = AVRDudeConfig(target)

    # See https://www.nongnu.org/avrdude/user-manual/avrdude_4.html
    cmd = [
        str(config.avrdude_bin),
        '-p', config.board,
        '-b', config.baudrate,
        '-c', config.uploader,
        '-C', str(config.avrdude_config),
        '-P', config.port,
        '-Ulfuse:w:{}:m'.format(config.lfuse),
        '-Uhfuse:w:{}:m'.format(config.hfuse),
        '-Uefuse:w:{}:m'.format(config.efuse)
        ]

    log.info('Burning fuses...')
    log.info('(E:{}, H:{}, L:{})'
                 .format(config.efuse, config.hfuse, config.lfuse))
    out = run(cmd)

    success = False
    return success, out

def _record_outcome(target, success, identity, outfile=None):
    if outfile is None:
        project_root = Path(__file__).resolve().parents[1]
        outfile = project_root / 'data' / 'flash_record.csv'

    outfile.parents[0].mkdir(parents=True, exist_ok=True)
    include_header_row = not outfile.exists()

    data = identity.to_csv(include_header_row)
    with open(str(outfile), 'a+') as f:
        if include_header_row:
            data[0] = ['target', 'success'] + data[0]
            csv = ','.join(data[0]) + os.linesep
            f.write(csv)
            data = data[1]

        data = [target, str(success)] + data
        csv = ','.join(data) + os.linesep
        f.write(csv)

def _generate_eeprom(target, input_data, **kwargs):
    """Generate a blob of eeprom hex based on some input data.

    input_data is expected to be a list of `(bytes, offset)`, where
    `bytes` is a string and `offset` the integer offset from
    the start of EEPROM memory.
    """
    config = AVRDudeConfig(target, **kwargs)

    # Generate blank eeprom data
    eeprom_data = '00' * config.eeprom['size']

    # Put input data into eeprom format
    log.debug(input_data)
    for pos, d in input_data:
        start = 2*pos  # 2 chars per byte
        end = len(d) + 2 * pos
        eeprom_data = eeprom_data[:start] + d + eeprom_data[end:]

    # Align eeprom data into rows
    byte_count = config.eeprom['line_byte_count']
    num_lines = config.eeprom['size'] // byte_count
    eeprom_data = [eeprom_data[i*2*byte_count:(i+1)*2*byte_count] 
                   for i in range(num_lines)]

    # Add eeprom metadata
    bc = "{:0X}".format(byte_count)
    addr = config.eeprom['starting_address']
    record_type = '00'
    eeprom = []
    for i, data in enumerate(eeprom_data):
        addr = config.eeprom['starting_address'] + i * byte_count
        addr = "{:04X}".format(addr)
        checksum = bc + addr + record_type + data
        # print(bc, addr, record_type, data)
        # print(len(bc), len(addr), len(record_type), len(data))
        record = ':{bc}{ad}{rt}{d}'.format(bc=bc, ad=addr, rt=record_type, d=data)
        record += _calculate_eeprom_checksum(record[1:])
        eeprom.append(record)

    # Add terminator record
    eeprom += [':00000001FF']
    eeprom = '\n'.join(eeprom)

    eeprom_path = Path(tempfile.gettempdir()) / 'eeprom.hex'
    with open(str(eeprom_path), 'w+') as f:
        f.write(eeprom)

    with open(str(eeprom_path), 'r+') as f:
        eeprom = str(f.read())
        log.info("Generated EEPROM: \n{}".format(eeprom))
    return str(eeprom_path)
    
def _parse_eeprom(eeprom):
    """Read a blob of eeprom hex from a device.

    Output is the eeprom as one hex string, stripped of any 
    non-payload fields.
    """
    eeprom_data = ''
    for d in eeprom.split('\n'):
        d = d[9:-2]
        eeprom_data += d

    return eeprom_data

def _calculate_eeprom_checksum(record):
    """Calculating checksum based on Intel HEX specification.
    
    https://en.wikipedia.org/wiki/Intel_HEX#Checksum_calculation
    """
    checksum = 0
    num_bytes = len(record) // 2
    for i in range(num_bytes):
        hex_byte = record[2*i:(2*i)+2]
        checksum += int(hex_byte, 16)

    # Take LSB of two's complement
    checksum = hex(((abs(checksum) ^ 0xffff) + 1) & 0xffff)[-2:]
    return checksum.upper()

if __name__ == "__main__":
    # list_usb_interfaces('battery')
    print(read_eeprom('battery'))
    # print(read_identity('fsb'))
    # flash_eeprom('battery', FAKE_ID)
