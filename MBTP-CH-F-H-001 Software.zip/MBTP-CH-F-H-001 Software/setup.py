#!/usr/bin/env python3

from setuptools import setup, find_packages

setup(
    name="mb_flash",
    version="1.0",
    description='Flashing tools for AVR and ESP devices.',
    author='Nick Sweet',
    author_email='nick@maidbot.com',
    classifiers=[ 
        'Development Status :: 3 - Alpha',
        'Intended Audience :: Developers',
        'Topic :: Software Development :: Build Tools',
        'Programming Language :: Python :: 3.5',
        'Programming Language :: Python :: 3.6',
        'Programming Language :: Python :: 3.7',
    ],
    python_requires='>=3.4, <4',
)