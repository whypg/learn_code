#! /bin/bash
echo "Installing avrdude prerequisites..."
REQUIRED_PACKAGES="flex
                   bison
                   byacc"

# apt-get update 
apt-get -y -qq -o Dpkg::Use-Pty=0 install ${REQUIRED_PACKAGES}

AVRDUDE_WS=$(dirname "$(readlink -f "$0")")
AVRDUDE_TARBALL="${AVRDUDE_WS}/avrdude-6.3.tar"
AVRDUDE_INSTALL_DIR="${AVRDUDE_WS}"

mkdir -p $AVRDUDE_INSTALL_DIR
echo "Unpacking the tarball..."
tar -xf ${AVRDUDE_TARBALL} -C ${AVRDUDE_WS}
if [ "$?" -ne "0" ]; then
  echo "Could not find the tarball at ${AVRDUDE_TARBALL}!"
  exit 1
fi

pushd "${AVRDUDE_INSTALL_DIR}"
echo "Configuring the package..."
./avrdude-6.3/configure #> /dev/null 2>&1
if [ "$?" -ne "0" ]; then
  echo "Could not configure avrdude!"
  popd
  exit 1
fi

echo "Building the package..."
make > /dev/null 2>&1
if [ "$?" -ne "0" ]; then
  echo "Could not build avrdude."
  exit 1
fi

echo "Done!"
popd

