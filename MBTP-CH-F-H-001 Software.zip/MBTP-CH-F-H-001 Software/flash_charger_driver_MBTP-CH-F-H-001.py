import sys
sys.path.insert(0, 'mb_flash')

try:
    import serial, cryptography, cffi
except ImportError:
    print("Missing packages! Please run:\n\tpip install -r requirements.txt")
    sys.exit(1)

from mb_flash.driver_gui import ChargerDriverGui

gui = ChargerDriverGui()
